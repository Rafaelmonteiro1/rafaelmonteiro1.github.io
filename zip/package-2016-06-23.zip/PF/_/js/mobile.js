$(function() {
	console.log('open');

	$('a[rel=link-menu]').click(function(event) {
		var target = $(this).attr('href');
		var menuHeight = $('.content').children('div').height();

		$("#01_00_Menu").height(menuHeight);

		$(target).show();
		return false;
	});

	$('a[rel=close-menu]').click(function() {
		$("#01_00_Menu").hide();
		return false;
	});
	

});