module.exports = function( grunt ) {

  grunt.initConfig({
    sass : {
      dist : {
        options : { 
          style : 'expanded',
          debugInfo : false
        },
        files : {
          'PF/_/css/pf-desktop.css' : 'PF/_/stylesheets/pf-desktop.scss'  ,
          'PF/_/css/pf-mobile.css'  : 'PF/_/stylesheets/pf-mobile.scss'   ,
          'PJ/_/css/pj-desktop.css' : 'PJ/_/stylesheets/pj-desktop.scss'  ,
          'PJ/_/css/pf-mobile.css'  : 'PJ/_/stylesheets/pj-mobile.scss'
        }
      }
    }, // sass
    watch : {
      dist : {
        files : [
          'PF/**/*',
          'PJ/**/*'
        ],
        tasks : [ 'sass' ]
      }
    }, // watch
    browserSync: {
        bsFiles: {
            src : [
              'PF/**/*',
              'PJ/**/*'
            ]
        },
        options: {
          watchTask: true,
          proxy: "safra-wf.localhost"
        }
    }
  });

  // Plugins do Grunt
  grunt.loadNpmTasks( 'grunt-contrib-imagemin' );
  grunt.loadNpmTasks( 'grunt-contrib-uglify' );
  grunt.loadNpmTasks( 'grunt-contrib-sass' );
  grunt.loadNpmTasks( 'grunt-contrib-watch' );
  grunt.loadNpmTasks( 'grunt-browser-sync' );

  // Tarefas que serão executadas
  grunt.registerTask( 'd', [ 'browserSync', 'watch' ] );
  grunt.registerTask( 'u', [ 'uglify' ] );
  grunt.registerTask( 's', [ 'sass' ] );
  grunt.registerTask( 'i', [ 'imagemin' ] );

  // Tarefa para Watch
  grunt.registerTask( 'w', ['watch'] );

};