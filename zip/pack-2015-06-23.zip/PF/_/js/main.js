$(function() {
	console.log('open');

	$('a[rel=link-menu]').click(function(event) {
		var target = $(this).attr('href');

		if ($(target).is(':visible')) {
			$(target).hide();
		}else{
			$('.hide').hide();
			$(target).show();
		};
		return false;
	});

	

});